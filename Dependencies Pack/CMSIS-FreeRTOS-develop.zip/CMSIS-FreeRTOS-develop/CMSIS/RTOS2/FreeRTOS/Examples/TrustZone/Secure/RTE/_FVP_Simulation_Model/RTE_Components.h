
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'TZ_Secure' 
 * Target:  'FVP Simulation Model' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "ARMCM33_DSP_FP_TZ.h"

/*  ARM.FreeRTOS::RTOS:TrustZone:10.2.0 */
#define RTE_RTOS_FreeRTOS_TZ


#endif /* RTE_COMPONENTS_H */
